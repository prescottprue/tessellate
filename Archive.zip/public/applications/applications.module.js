angular.module('tessellate.applications', [
	'ngMaterial',
	'tessellate.application'
])
